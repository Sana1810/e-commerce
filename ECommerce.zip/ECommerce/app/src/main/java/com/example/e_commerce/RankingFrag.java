package com.example.e_commerce;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class RankingFrag extends Fragment implements CategoryViewAdapter.MyInterface {
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private CategoryViewAdapter adapter;
    AllProductsResponse responseList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_ranking, container, false);

        recyclerView = view.findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        adapter = new CategoryViewAdapter(getActivity(), responseList, this);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);

        return  view;
    }

    @Override
    public int getPos(int position, String listType) {
        Intent intent = new Intent(getActivity(), ProductActivity.class)
                .putExtra("position", String.valueOf(position))
                .putExtra("playlistType", listType);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        return position;
    }
}
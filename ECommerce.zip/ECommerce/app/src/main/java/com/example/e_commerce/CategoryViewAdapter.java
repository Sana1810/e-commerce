package com.example.e_commerce;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CategoryViewAdapter extends RecyclerView.Adapter<CategoryViewAdapter.ViewHolder> {

    Context context;
    AllProductsResponse responseList;
    MyInterface inter;

    public CategoryViewAdapter(Context context, AllProductsResponse responseList, MyInterface inter) {
        this.context = context;
        this.responseList = responseList;
        this.inter = inter;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.activity_category_view_adapter, parent, false);
        return new CategoryViewAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public interface MyInterface {

        int getPos(int position, String listType);

    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        LinearLayout linearLayout;
        TextView txt_cat;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            txt_cat = itemView.findViewById(R.id.txt_cat);
            linearLayout = itemView.findViewById(R.id.linear_layout);
        }
    }
}
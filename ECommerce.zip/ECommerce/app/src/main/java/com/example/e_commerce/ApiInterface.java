package com.example.e_commerce;

import androidx.annotation.AnyRes;

import retrofit2.Call;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;

import java.util.List;

public interface ApiInterface {

    @GET("json")
    Call<Object> getDetail();

}

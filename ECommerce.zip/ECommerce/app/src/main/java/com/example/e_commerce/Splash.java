package com.example.e_commerce;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

public class Splash extends AppCompatActivity {
    private static int SPLASH_SCREEN_TIME_OUT = 3000;
    SharedPreferences pref;
    String password, userName;
    Handler handler;
    public static MyAppDatabase myAppDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        myAppDatabase = Room.databaseBuilder(getApplicationContext(), MyAppDatabase.class, "All_Products").allowMainThreadQueries().fallbackToDestructiveMigration().build();
        pref = getSharedPreferences("MyPref", MODE_PRIVATE);
        userName = pref.getString("nameKey", "");
        password = pref.getString("passKey", "");

        Log.e("userName", userName);
        Log.e("userName", password);

        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                if (password.isEmpty() && userName.isEmpty()) {

                    Intent i = new Intent(Splash.this, MainActivity.class);
                    startActivity(i);
                    finish();

                } else {

                    Intent i = new Intent(Splash.this, DashBoard.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    finish();

                }
            }
        }, SPLASH_SCREEN_TIME_OUT);
    }
}
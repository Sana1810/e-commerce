package com.example.e_commerce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class Registration extends AppCompatActivity {

    EditText edt_name, edt_password, edt_email, edt_phoneNum, edt_address;
    TextView txt_registration,txt_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        edt_name = findViewById(R.id.edt_name);
        edt_password = findViewById(R.id.edt_password);
        edt_email = findViewById(R.id.edt_email);
        edt_phoneNum = findViewById(R.id.edt_phoneNum);
        edt_address = findViewById(R.id.edt_address);
        txt_registration = findViewById(R.id.txt_registration);
        txt_login = findViewById(R.id.txt_login);

        txt_registration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registrationData();
            }
        });
        txt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Registration.this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                finish();
            }
        });
    }

    private void registrationData() {
        String name = edt_name.getText().toString();
        String password = edt_password.getText().toString();
        String email = edt_email.getText().toString();
        String phoneNum = edt_phoneNum.getText().toString();
        String address = edt_address.getText().toString();

        if(name.isEmpty()||password.isEmpty()){
            Toast.makeText(getApplicationContext(),"Enter your name and password", Toast.LENGTH_SHORT).show();
        }
        else {
            RegistrationResponse registrationResponse = new RegistrationResponse();
            registrationResponse.setName(name);
            registrationResponse.setPassword(password);
            registrationResponse.setEmail(email);
            registrationResponse.setPhoneNumber(phoneNum);
            registrationResponse.setAddress(address);

            Splash.myAppDatabase.myDAO().add(registrationResponse);
            Toast.makeText(getApplicationContext(), "Successfully Registered", Toast.LENGTH_SHORT).show();

            edt_name.setText("");
            edt_email.setText("");
            edt_password.setText("");
            edt_phoneNum.setText("");
            edt_address.setText("");

            startActivity(new Intent(Registration.this, MainActivity.class));

        }
    }
}
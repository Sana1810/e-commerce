package com.example.e_commerce;

import androidx.annotation.AnyRes;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.room.Room;

import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    TextView txt_logIn, txt_signUp, txt_signup_bottom;
    EditText edt_name, edt_password;
    public Class<AllProductsResponse> type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt_logIn = findViewById(R.id.txt_logIn);
        txt_signUp = findViewById(R.id.txt_signUp);
        edt_name = findViewById(R.id.edt_name);
        edt_password = findViewById(R.id.edt_password);
        txt_signup_bottom = findViewById(R.id.txt_signup_bottom);

        txt_logIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<RegistrationResponse> registrations = Splash.myAppDatabase.myDAO().getUsers();

                for (RegistrationResponse reg : registrations) {
                    String m_name = reg.getName();
                    String m_password = reg.getPassword();

                    if (m_name.isEmpty() || m_password.isEmpty())
                        Toast.makeText(getApplicationContext(), "Invalid name or password", Toast.LENGTH_SHORT).show();
                    else if (edt_name.getText().toString().equals(m_name) && edt_password.getText().toString().equals(m_password)) {
                        Intent intent = new Intent(MainActivity.this, DashBoard.class);
                        startActivity(intent);
                    }
                }

                LogIn_API();
            }
        });

        txt_signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registrationPage();
//                Roles_API();

            }
        });

        txt_signup_bottom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registrationPage();
            }
        });
    }

    private void registrationPage() {
        Intent i = new Intent(MainActivity.this, Registration.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }

    private void LogIn_API() {

        ApiInterface apiInterface = InterfaceGenerator.createService().create(ApiInterface.class);
        Call<Object> call = apiInterface.getDetail();
        call.enqueue(new Callback<Object>() {

            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
//                    Toast.makeText(getApplicationContext(), response.code(), Toast.LENGTH_SHORT).show();
                Gson gson = new Gson();
                String strJson = gson.toJson(response.body());
                Log.e("response_abc", strJson);

//                AllProductsResponse response1 = new AllProductsResponse();
//                response1 = type.cast(response.body());
//                Gson gson1 = new Gson();
//                String strJson1 = gson1.toJson(response1.getCategories());
//                Log.e("response", strJson1);
            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Failure", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
package com.example.e_commerce;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "All_Products")
public class All_Products {
    @PrimaryKey(autoGenerate = true)
    int id;

    int c_id;
    String c_name;
    int p_id;
    String p_name;
    String date_added;
    int v_id;
    String v_color;
    int v_price;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getC_id() {
        return c_id;
    }

    public void setC_id(int c_id) {
        this.c_id = c_id;
    }

    public String getC_name() {
        return c_name;
    }

    public void setC_name(String c_name) {
        this.c_name = c_name;
    }

    public int getP_id() {
        return p_id;
    }

    public void setP_id(int p_id) {
        this.p_id = p_id;
    }

    public String getP_name() {
        return p_name;
    }

    public void setP_name(String p_name) {
        this.p_name = p_name;
    }

    public String getDate_added() {
        return date_added;
    }

    public void setDate_added(String date_added) {
        this.date_added = date_added;
    }

    public int getV_id() {
        return v_id;
    }

    public void setV_id(int v_id) {
        this.v_id = v_id;
    }

    public String getV_color() {
        return v_color;
    }

    public void setV_color(String v_color) {
        this.v_color = v_color;
    }

    public int getV_price() {
        return v_price;
    }

    public void setV_price(int v_price) {
        this.v_price = v_price;
    }

    public int getV_size() {
        return v_size;
    }

    public void setV_size(int v_size) {
        this.v_size = v_size;
    }

    public String getT_name() {
        return t_name;
    }

    public void setT_name(String t_name) {
        this.t_name = t_name;
    }

    public int getT_value() {
        return t_value;
    }

    public void setT_value(int t_value) {
        this.t_value = t_value;
    }

    public int getR_id() {
        return r_id;
    }

    public void setR_id(int r_id) {
        this.r_id = r_id;
    }

    public String getView_count() {
        return view_count;
    }

    public void setView_count(String view_count) {
        this.view_count = view_count;
    }

    public String getOrder_count() {
        return Order_count;
    }

    public void setOrder_count(String order_count) {
        Order_count = order_count;
    }

    public String getShares() {
        return shares;
    }

    public void setShares(String shares) {
        this.shares = shares;
    }

    int v_size;
    String t_name;
    int t_value;
    int r_id;
    String view_count;
    String Order_count;
    String shares;
}

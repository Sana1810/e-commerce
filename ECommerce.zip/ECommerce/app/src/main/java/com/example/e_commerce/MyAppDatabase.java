package com.example.e_commerce;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {All_Products.class,RegistrationResponse.class}, version = 1)
public abstract class MyAppDatabase extends RoomDatabase {

    public abstract MyDAO myDAO();
}

package com.example.e_commerce;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Product__1 {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("view_count")
    @Expose
    private String viewCount;
    @SerializedName("order_count")
    @Expose
    private String orderCount;
    @SerializedName("shares")
    @Expose
    private String shares;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getViewCount() {
        return viewCount;
    }

    public void setViewCount(String viewCount) {
        this.viewCount = viewCount;
    }

    public String getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(String orderCount) {
        this.orderCount = orderCount;
    }

    public String getShares() {
        return shares;
    }

    public void setShares(String shares) {
        this.shares = shares;
    }
}

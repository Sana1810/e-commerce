package com.example.e_commerce;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.e_commerce.All_Products;

import java.util.List;

@Dao
public interface MyDAO {

    @Insert
    public void add(RegistrationResponse registrationResponse);

    @Query("select * from Registration")
    public List<RegistrationResponse> getUsers();

    @Insert
    public void add(All_Products all_products);
}

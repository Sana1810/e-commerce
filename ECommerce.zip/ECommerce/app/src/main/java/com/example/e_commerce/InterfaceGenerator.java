package com.example.e_commerce;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class InterfaceGenerator {

    public static final String BASE_URL = "https://stark-spire-93433.herokuapp.com/";
    public static Retrofit createService(){
        return new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }
}
